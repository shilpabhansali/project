var app = angular.module('myApp',['ngRoute'])
.config(['$routeProvider', function ($routeProvider) { 
	  $routeProvider
	    .when('/',{ 
		  controller: 'LoginController', 
	      templateUrl: 'views/login.html'
		  })
		.when('/register',{ 
			controller: 'LoginController', 
			templateUrl: 'views/register.html'
		  })
		.when('/home',{ 
			controller: 'LoginController', 
			templateUrl: 'views/home.html'
		  })
		.when('/post',{ 
			controller: 'LoginController', 
			templateUrl: 'views/createPost.html'
		  })
		  .when('/login', { 
			controller: 'LoginController', 
			templateUrl: 'views/login.html' 
		  })
		  .when('/about', { 
			controller: 'LoginController', 
			templateUrl: 'views/about.html' 
		  })
		  .when('/categories', { 
			controller: 'LoginController', 
			templateUrl: 'views/categories.html' 
		  })
		  .when('/contact', { 
			controller: 'LoginController', 
			templateUrl: 'views/contact.html' 
		  })
		  .when('/profile', { 
			controller: 'LoginController', 
			templateUrl: 'views/profile.html' 
		  })
		  .when('/otherProfile', { 
			controller: 'LoginController', 
			templateUrl: 'views/otherProfile.html' 
		  })
		  .when('/profileEdit', { 
			controller: 'ProfileEditController', 
			templateUrl: 'views/profileEdit.html' 
		  })
	    
}]);

