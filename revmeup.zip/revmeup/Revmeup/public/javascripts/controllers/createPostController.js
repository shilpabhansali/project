


(function () {
	'use strict';
	angular
	.module('myApp').controller('createPostController', createPostController);

	createPostController.$inject = ['$scope', '$log', '$window'];
	function createPostController($scope, $log, $window) {

		var vm = this;
		
		
	};

})();