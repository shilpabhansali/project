var mysql = require('mysql');
var qs = require('querystring');

exports.loginUser = function(reqBody){
	var Users;
	var con = mysql.createConnection({
  host: "localhost",		
  user: "root",
  password: "$hashanK1",
  database: "revmeup",
  insecureAuth : true
});

con.connect(function(err) {
	console.log(reqBody);
  var username = reqBody.name;
  var password = reqBody.password;
  console.log(username);
  console.log(password);
  
  if (err) throw err;
  console.log("Connected!");
  var sql = "Select * from User Where Username = " + mysql.escape(username) + " AND password = " + password;
    
  con.query(sql, function (err, result, fields) {
    if (err) throw err;
    console.log("Current User " + result);
    return result;
  });
});
}
