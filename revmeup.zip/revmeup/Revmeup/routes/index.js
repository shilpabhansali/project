var express = require('express');
var router = express.Router();
var path = require('path');
var createPost = require('./createPost');
const fs = require('fs');
var formidable = require('formidable');
var mysql = require('mysql');
var qs = require('querystring');

var bodyParser = require('body-parser')
router.use( bodyParser.json() );       // to support JSON-encoded bodies
router.use(bodyParser.urlencoded({     // to support URL-encoded bodies
  extended: true
})); 

 
/* GET home page. */

router.get('/', function(req, res, next) {
  res.sendFile(path.join(__dirname, '../', 'public/views', 'index.html'));
});


router.post('/createPost', function(req, res, next){
	console.log(req.url);

  createPost.createPost(req, res);
	res.write('File Uploaded successfully');
res.end();
  	//res.render('/#/post');
});

module.exports = router;