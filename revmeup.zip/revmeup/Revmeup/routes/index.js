var express = require('express');
var router = express.Router();
var path = require('path');
var createPost = require('./createPost');
var registerUser = require('./registerUser');
var loginUser = require('./loginUser');

var bodyParser = require('body-parser')
router.use( bodyParser.json() );       // to support JSON-encoded bodies
router.use(bodyParser.urlencoded({     // to support URL-encoded bodies
  extended: true
})); 

 
/* GET home page. */

router.get('/', function(req, res, next) {
  res.sendFile(path.join(__dirname, '../', 'public/views', 'index.html'));
});

router.get('/loginUser', function(req, res, next){
  var reqBody = req.body;
  var currentUserData = loginUser.loginUser(reqBody);
  res.write(currentUserData);
  res.end();
  console.log('currentUserData' + currentUserData);
});

router.post('/registerUser', function(req, res, next) { 
  var reqBody = req.body;
  registerUser.registerUser(reqBody);
  res.write('User Registered successfully');
  res.end();
  //res.render('login');
});

router.post('/createPost', function(req, res, next){
	console.log(req.url);

  createPost.createPost(req, res);
  console.log('inside router indesx.js');
	//res.write('File Uploaded successfully');
//res.end();
  	//res.render('/#/post');
});

module.exports = router;