var mysql = require('mysql');
var qs = require('querystring');

exports.Registeration = function(req, res){
	var Users;
	var con = mysql.createConnection({
  host: "localhost",		
  user: "root",
  password: "$hashanK1",
  database: "revmeup",
  insecureAuth : true
});

con.connect(function(err) {
	var reqBody;
	var username;
	var password;
	req.on("data", function(data){
		reqBody = reqBody + data;
	})
	req.on("end", function(data){
		username = qs.parse(reqBody).Username;
		password = qs.parse(reqBody).pass;
	})
  if (err) throw err;
  console.log("Connected!");
  var sql = "INSERT INTO User (Username, Password) VALUES ?";
  var values = [
    ['John', 'Highway 71'],
    ['Peter', 'Lowstreet 4'],
    ['Amy', 'Apple st 652'],
    ['Hannah', 'Mountain 21'],
    ['Michael', 'Valley 345'],
    ['Sandy', 'Ocean blvd 2'],
    ['Betty', 'Green Grass 1'],
    ['Richard', 'Sky st 331'],
    ['Susan', 'One way 98'],
    ['Vicky', 'Yellow Garden 2'],
    ['Ben', 'Park Lane 38'],
    ['William', 'Central st 954'],
    ['Chuck', 'Main Road 989'],
    ['Viola', 'Sideway 1633']
  ];
  con.query(sql, [values], function (err, result) {
    if (err) throw err;
    console.log("Number of records inserted: " + result.affectedRows);
  });
});
}
