
(function () {
	'use strict';
	angular
	.module('myApp').controller('createPostController', createPostController);

	createPostController.$inject = ['$rootScope', '$log', '$window', 'PostService', '$scope'];
	function createPostController($rootScope, $log, $window, PostService, $scope) {
		$scope.product = {
			productName: "",
			productRate:"",
			productTitle: "",
			productPros: "",
			productCons: "",
			productReview: "",
			productRecommend:"",
			productImage: "",
		};
		
		$rootScope.navBar = true;

		document.getElementById("productPic").onchange = function(event){
        var file = $scope.product.productImage;
            console.log('file is ' );
            console.dir(file);
            
        }; 
		
		/*document.getElementById("productPic").onchange = function(event){
			$scope.product.productImage = event.target.files[0].name;
		};
*/

		$scope.post = function () {
			console.log("POST called");
			PostService.Post($scope.product).then(function(response) {
				console.log(response);
				alert(JSON.stringify(response));
				location.href = "/#post";
				
				
		}, function(error) {
					
			console.log(error);
			alert("UNABLE TO START JOB: " + error.message);
		});
		

	};
	}
})();