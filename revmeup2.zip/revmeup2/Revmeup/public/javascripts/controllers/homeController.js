/**
 * Home Controller
 */

(function () {
	'use strict';

	angular
	.module('myApp')
	.controller('HomeController', HomeController);

	HomeController.$inject = ['$rootScope','$log', '$window', '$timeout'];
	function HomeController($rootScope, $log, $window, $timeout) {
		var vm = this;
		$rootScope.navBar = true;//for the navigation bar

	}

})();