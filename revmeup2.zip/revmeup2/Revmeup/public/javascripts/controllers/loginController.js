/**
 * Login Controller
 */

(function () {
	'use strict';

	angular
	.module('myApp')
	.controller('LoginController', LoginController);

	LoginController.$inject = ['$rootScope', '$log', '$window', 'LoginService','$scope'];
	function LoginController($rootScope, $log, $window, LoginService,$scope) {
		$scope.user = {
			name: "",
			password:""
		};
		$rootScope.navBar = false;
		
		$scope.login = function () {
			console.log("LOGIN called");
			LoginService.Login($scope.user).then(function(response) {
				console.log(response);
				//alert(JSON.stringify(response));
				//I want to set User object to rootscope
				
				alert("User Logged in successfully!");
				$rootScope.posts = response.posts;
				$scope.navBar = true;
				location.href = "/#home";
				
				
		}, function(error) {
			console.log(error);
			alert(error.message);		//login Failed
		});
	};
	$scope.registerUser = function () {
		console.log("Register User called");
		LoginService.Register($scope.user).then(function(response) {
			console.log(response);
			alert(JSON.stringify(response));
			location.href = "/#categories";
			
			
	}, function(error) {
		console.log(error);
		alert("UNABLE TO START JOB: " + error.message);
	});
};
	}
})();