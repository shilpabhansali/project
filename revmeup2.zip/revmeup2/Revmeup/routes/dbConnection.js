var mysql=require('mysql');
 var connection=mysql.createPool({
 
host:'localhost',
 host: "localhost",		
  user: "root",
  password: "$hashanK1",
  database: "revmeup",
  insecureAuth : true
});
 module.exports=connection;