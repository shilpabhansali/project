/**
 * Main Controller
 */

(function () {
	'use strict';

	angular
	.module('myApp')
	.controller('MainController', MainController);

	MainController.$inject = ['$rootScope','$log', '$window', '$timeout'];
	function MainController($rootScope, $log, $window, $timeout) {
		var vm = this;
		$rootScope.navBar = false;//for the navigation bar

	}

})();