
(function () {
	'use strict';
	angular
	.module('myApp').controller('createPostController', createPostController);

	createPostController.$inject = ['$rootScope', '$log', '$window', 'PostService'];
	function createPostController($rootScope, $log, $window, PostService) {
		$rootScope.product = {
			productName: "",
			productRate:"",
			productTitle: "",
			productPros: "",
			productCons: "",
			productReview: "",
			productImage: "",
		};
		var vm = this;
		$rootScope.post = function () {
			console.log("POST called");
			PostService.Post($rootScope.product).then(function(response) {
				console.log(response);
				alert(JSON.stringify(response));
				$rootScope.navBar = true;
				location.href = "/#post";
				
				
		}, function(error) {
					
			console.log(error);
			alert("UNABLE TO START JOB: " + error.message);
		});
		

	};
	}
})();