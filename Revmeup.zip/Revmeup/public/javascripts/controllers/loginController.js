/**
 * Login Controller
 */

(function () {
	'use strict';

	angular
	.module('myApp')
	.controller('LoginController', LoginController);

	LoginController.$inject = ['$rootScope', '$log', '$window', 'LoginService'];
	function LoginController($rootScope, $log, $window, LoginService) {
		$rootScope.user = {
			//name: "",
			//password:""
		};
		var vm = this;
		vm.name = "hi";
		$rootScope.login = function () {
			console.log("LOGIN called");
			LoginService.Login($rootScope.user).then(function(response) {
				console.log(response);
				alert(JSON.stringify(response));
				vm.name = response.route;
				$rootScope.navBar = true;
				location.href = "/#home";
				
				
		}, function(error) {
					
			console.log(error);
			alert("UNABLE TO STRAT JOB: " + error.message);
		});
		

	};
	}
})();