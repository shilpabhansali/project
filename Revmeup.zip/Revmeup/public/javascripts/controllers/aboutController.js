/**
 * About Controller
 */

(function () {
	'use strict';

	angular
	.module('myApp')
	.controller('AboutController', AboutController);

	AboutController.$inject = ['$rootScope', '$log', '$window', 'GetPostService'];

	function AboutController($rootScope, $log, $window, GetPostService) {

		var vm = this;
		$rootScope.navBar = true;	//for the header
		$rootScope.popoverIsVisible = false;

		$rootScope.showPopover = function() {
			$rootScope.popoverIsVisible = true; 
		};

		$rootScope.hidePopover = function () {
			$rootScope.popoverIsVisible = false;
		};
	};

})();