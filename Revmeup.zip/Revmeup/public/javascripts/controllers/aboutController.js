/**
 * About Controller
 */

(function () {
	'use strict';

	angular
	.module('myApp')
	.controller('AboutController', AboutController);

	AboutController.$inject = ['$rootScope', '$log', '$window', 'GetPostService','$scope'];

	function AboutController($rootScope, $log, $window, GetPostService, $scope) {

		var vm = this;
		$rootScope.navBar = true;	//for the header
		$scope.popoverIsVisible = false;

		$scope.showPopover = function() {
			$scope.popoverIsVisible = true; 
		};

		$scope.hidePopover = function () {
			$scope.popoverIsVisible = false;
		};
	};

})();