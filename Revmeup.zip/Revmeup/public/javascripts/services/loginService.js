/**
 * Login Service
 */

(function () {
	'use strict';

	angular
	.module('myApp')
	.factory('LoginService', LoginService);

	LoginService.$inject = ['$rootScope', '$http', '$q', '$log'];
	function LoginService($rootScope, $http, $q, $log) {
		
		var service = {};

		service.Login = login;
		service.Register = register;
		
		return service;

		function register(userInput) {
			
			var deferred = $q.defer();
			$http({
				method: 'POST',
				url: '/registerUser',
				data: userInput
			}).then(function successCallback(response) {
				deferred.resolve(response.data);
				console.log("service called!!");
			}, function errorCallback(response) {

				deferred.reject(new Error("ERROR: UNABLE TO GET DOCS"));
			});
			
			return deferred.promise;
		};
		function login(userInput) {
			
			var deferred = $q.defer();
			$http({
				method: 'POST',
				url: '/loginUser',
				data: userInput
			}).then(function successCallback(response) {
				deferred.resolve(response.data);
				console.log("service called!!");
			}, function errorCallback(response) {

				deferred.reject(new Error("ERROR: User name or password is not matching"));
			});
			
			return deferred.promise;
		}
	}
})();