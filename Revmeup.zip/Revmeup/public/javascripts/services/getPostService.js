/**
 *  Get Post Service
 */

(function () {
	'use strict';

	angular
	.module('myApp')
	.factory('GetPostService', GetPostService);

	GetPostService.$inject = ['$rootScope', '$http', '$q', '$log'];
	function GetPostService($rootScope, $http, $q, $log) {
		
		var service = {};

		service.GetPost = getPost;
		
		return service;

		function getPost(userInput) {
			
			var deferred = $q.defer();
			$http({
				method: 'POST',
				url: '/loginUser',
				data: userInput
			}).then(function successCallback(response) {
				deferred.resolve(response.data);
				console.log("service called!!");
			}, function errorCallback(response) {

				deferred.reject(new Error("ERROR" + response.status));
			});
			
			return deferred.promise;
		}
	}
})();