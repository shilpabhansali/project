/**
 * Post Service
 */

(function () {
	'use strict';

	angular
	.module('myApp')
	.factory('PostService', PostService);

	PostService.$inject = ['$rootScope', '$http', '$q', '$log'];
	function PostService($rootScope, $http, $q, $log) {
		
		var service = {};

		service.Post = post;
		
		return service;

		function post(product) {
			
			var deferred = $q.defer();
			$http({
				method: 'POST',
				url: '/createPost',
				data: product
			}).then(function successCallback(response) {
				deferred.resolve(response.data);
				console.log("service called!!");
			}, function errorCallback(response) {

				deferred.reject(new Error("ERROR: UNABLE TO GET DOCS: " + response.status));
			});
			
			return deferred.promise;
		}
	}
})();