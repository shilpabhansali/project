var app = angular.module('myApp',['ngRoute'])
.config(['$routeProvider', function ($routeProvider) { 
	  $routeProvider
	  .when('/',{ 
		  controller: 'MainController', 
	      templateUrl: 'views/login.html'
		})
		.when('/register',{ 
			controller: 'MainController', 
			templateUrl: 'views/register.html'
		  })
	    
}]);

