var app = angular.module('myApp',['ngRoute'])
.config(['$routeProvider', function ($routeProvider) { 
	  $routeProvider
	    .when('/',{ 
		  controller: 'LoginController', 
	      templateUrl: 'views/login.html'
		  })
		.when('/register',{ 
			controller: 'LoginController', 
			templateUrl: 'views/register.html'
		  })
		.when('/home',{ 
			controller: 'HomeController', 
			templateUrl: 'views/home.html'
		  })
		.when('/post',{ 
			controller: 'createPostController', 
			templateUrl: 'views/createPost.html'
		  })
		  .when('/login', { 
			controller: 'LoginController', 
			templateUrl: 'views/login.html' 
		  })
		  .when('/about', { 
			controller: 'AboutController', 
			templateUrl: 'views/about.html' 
		  })
		  .when('/categories', { 
			controller: 'HomeController', 
			templateUrl: 'views/categories.html' 
		  })
		  .when('/contact', { 
			controller: 'LoginController', 
			templateUrl: 'views/contact.html' 
		  })
		  .when('/profile', { 
			controller: 'LoginController', 
			templateUrl: 'views/profile.html' 
		  })
		  .when('/otherProfile', { 
			controller: 'LoginController', 
			templateUrl: 'views/otherProfile.html' 
		  })
		  .when('/profileEdit', { 
			controller: 'ProfileEditController', 
			templateUrl: 'views/profileEdit.html' 
		  })
	    
}]);

