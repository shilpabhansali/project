var mysql = require('mysql');
var qs = require('querystring');

exports.registerUser = function(reqBody){
	var Users;
	var con = mysql.createConnection({
  host: "localhost",		
  user: "root",
  password: "revmeup123",
  database: "revmeup",
  insecureAuth : true
});

con.connect(function(err) {
	console.log(reqBody);
  var username = reqBody.name;
  var password = reqBody.password;
  console.log(username);
  console.log(password);
  
  if (err) throw err;
  console.log("Connected!");
  var sql = "INSERT INTO User (Username, Password) VALUES ?";
  var values = [];
  var creds = [];
  creds[0] = username;
  creds[1] = password;
  values[0] = creds;
    
  con.query(sql, [values], function (err, result) {
    if (err) throw err;
    console.log("Number of records inserted: " + result.affectedRows);
  });
});
}
