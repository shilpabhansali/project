var db=require('./dbconnection'); //reference of dbconnection.js
 
var Posts={
	

getPostsForCurrentUser:function(reqBody,callback){
	console.log('inside getPostsForCurrentUser');
	console.log('reqbody'+reqBody);
return db.query("select * from Product_Review where UserId=? ",[reqBody],callback);
 },
};
 module.exports=Posts;