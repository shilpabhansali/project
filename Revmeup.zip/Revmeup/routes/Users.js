var db=require('./dbconnection'); //reference of dbconnection.js
 
var Users={
	
getAllUsers:function(currentUser,callback){
 //console.log('inside getallusers');
 console.log(currentUser);
 console.log(currentUser.password);
//return db.query("select * from User where Username=? AND Password =? ",[currentUser.username, currentUser.password],callback);
 
},
loginUser:function(reqBody,callback){
	console.log('inside loginUser');
	console.log('reqbody'+reqBody.password);
return db.query("select * from User where Username=? AND Password =? limit 1 ",[reqBody.name, reqBody.password],callback);
 },
 getUserById:function(id,callback){
 
return db.query("select * from User where Id=?",[id],callback);
 },
 addTask:function(Task,callback){
 return db.query("Insert into task values(?,?,?)",[Task.Id,Task.Title,Task.Status],callback);
 },
 deleteTask:function(id,callback){
  return db.query("delete from task where Id=?",[id],callback);
 },
 updateTask:function(id,Task,callback){
  return db.query("update task set Title=?,Status=? where Id=?",[Task.Title,Task.Status,id],callback);
 }
 
};
 module.exports=Users;