var express = require('express');
var router = express.Router();
var path = require('path');

var bodyParser = require('body-parser')
router.use( bodyParser.json() );       // to support JSON-encoded bodies
router.use(bodyParser.urlencoded({     // to support URL-encoded bodies
  extended: true
})); 

 
/* GET home page. */

router.get('/', function(req, res, next) {
  res.sendFile(path.join(__dirname, '../', 'public/views', 'index.html'));
});

router.get('/login', function(req, res, next) {
  //res.json({page:"login"});
  res.sendFile(path.join(__dirname, '../', 'public/views', 'login.html'));
});



router.get('/#home', function(req, res, next) {
  console.log("home page viewed");
  res.sendFile(path.join(__dirname, '../', 'views', 'home.html'));
});

router.get('/about', function(req, res, next) {
  res.sendFile(path.join(__dirname, '../', 'views', 'about.html'));
});

router.get('/categories', function(req, res, next) {
  res.sendFile(path.join(__dirname, '../', 'views', 'categories.html'));
});

router.post('/registerUser', function(req, res, next) {
  //console.log('hell0');
  res.json({route: "Register", data: req.body});
  //res.sendFile(path.join(__dirname, '../', 'views', 'categories.html'));
});


 
module.exports = router;