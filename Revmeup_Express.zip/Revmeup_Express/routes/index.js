var express = require('express');
var registerUser = require('./registerUser');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('login', { title: 'Express' });
});

router.get('/register', function(req, res, next) {
  res.render('register');
});

router.get('/login', function(req, res, next) {
	
  res.render('login');
});

router.post('/home', function(req, res, next) {
	
  res.render('home');
});

router.get('/about', function(req, res, next) {
	
  res.render('about');
});

router.get('/categories', function(req, res, next) {
	
  res.render('categories');
});

router.get('/contact', function(req, res, next) {
	
  res.render('contact');
});

router.get('/post', function(req, res, next) {
	
  res.render('post');
});

router.get('/profile', function(req, res, next) {
	
  res.render('profile');
});

router.post('/registerUser', function(req, res, next) { 
  var reqBody = req.body;
  registerUser.registerUser(reqBody);
  res.render('login');
});
module.exports = router;
