var mysql = require('mysql');
var qs = require('querystring');
var formidable = require('formidable'); 
var path = require('path');
var fs = require('fs');
var con = mysql.createConnection({
  host: "localhost",    
  user: "root",
  password: "revmeup123",
  database: "revmeup",
  insecureAuth : true
});


exports.createPost = function(req, res){
console.log('inside creaetePost'+req);
  var form = new formidable.IncomingForm();
  console.log("After form");
  form.parse(req, function(err, fields, files){
    console.log("Inside form");
    var oldpath = files.productPic.path;
    console.log(oldpath);
    var newpath = './public/images/images_upload/'+files.productPic.name;
    fs.rename(oldpath, newpath, function (err) {
        if (err) throw err;
        con.connect(function(err){
  var product = fields.product;
  var rating = fields.rating;
  var caption = fields.caption;
  var pros = fields.pros;
  var cons = fields.cons;
  var review = fields.review;
  var recommend = fields.recommend;  
  var pic = newpath;
        
  console.log("Connected!");
  var sql = "INSERT INTO product_review (Product, Rating, Caption, Pros, Cons, Review, Recommend, Product_Image) VALUES ?";
  var values = [];
  var postDatasql = [];
  postDatasql[0] = product;
  postDatasql[1] = rating;
  postDatasql[2] = caption;
  postDatasql[3] = pros;
  postDatasql[4] = cons;
  postDatasql[5] = review;
  postDatasql[6] = recommend;
  postDatasql[7] = pic;
  values[0] = postDatasql;
  
  console.log(sql);
  console.log(values);

  con.query(sql, [values], function(err, result){
    if (err) throw err;
    console.log("Number of post inserted: " + result.affectedRows);
    //res.sendFile(path.join(__dirname, '../', 'public/views', 'index.html'));
    res.end();
  });
        //res.end();
      });
        
  });
	
});
}