var db=require('./dbconnection'); //reference of dbconnection.js
 
var Posts={
	
createPostForCurrentUser:function(product, callback){

console.log('inside createPost');
console.log(product);

  var values = [];
  var postDatasql = [];
  postDatasql[0] = product.productName;
  postDatasql[1] = product.productRate;
  postDatasql[2] = product.productTitle;
  postDatasql[3] = product.productPros;
  postDatasql[4] = product.productCons;
  postDatasql[5] = product.productReview;
  postDatasql[6] = product.productRecommend;
  postDatasql[7] = product.productImage;
  postDatasql[8] = product.productUser.UserId;
  values[0] = postDatasql;
  console.log(values);

return db.query("INSERT INTO product_review (Product, Rating, Caption, Pros, Cons, Review, Recommend, Product_Image, UserId) VALUES ? ",[values],callback);

 },

getPostsForCurrentUser:function(reqBody,callback){
	console.log('inside getPostsForCurrentUser');
	console.log('reqbody'+reqBody);
return db.query("select * from Product_Review where UserId=? ",[reqBody],callback);
 },

 
};
 module.exports=Posts;