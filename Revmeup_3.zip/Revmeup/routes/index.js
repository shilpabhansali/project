var express = require('express');
var session = require('express-session');
var router = express.Router();
var path = require('path');
var createPost = require('./createPost');
var registerUser = require('./registerUser');
var Users = require('./Users');
var Posts = require('./Posts');
var multer = require('multer');

var storage = multer.diskStorage({
  destination: function(req, file, cb){
    cb(null, './public/images/images_upload/');
  },
  filename: function(req, file, cb){
    cb(null, file.originalname);
  }
});
var upload = multer({storage: storage}).single('ProductImage');

var bodyParser = require('body-parser')
router.use( bodyParser.json() );       // to support JSON-encoded bodies
router.use(bodyParser.urlencoded({     // to support URL-encoded bodies
  extended: true
})); 

 
/* GET home page. */

router.get('/', function(req, res, next) {
  console.log(req.session);
  userSession = req.session;
  userSession.username;
  userSession.password;
  userSession.userid;
  res.sendFile(path.join(__dirname, '../', 'public/views', 'index.html'));
});

router.post('/loginUser', function(req, res, next){
  
  var reqBody = req.body;
  var currentUser;
  var posts;
  var totalData = {};
  var jsonTotalData;
  Users.loginUser(reqBody, function(err,rows, fields){
  console.log(rows);
  if(err)
  {
    
  //res.json(err);
  }
  else{
    console.log(rows[0].UserId);
    currentUser = rows[0];
    req.session.username = currentUser.Username;
    req.session.password = currentUser.Password;
    req.session.userid = currentUser.UserId;
    
    Posts.getPostsForCurrentUser(currentUser.UserId, function(err,rows, fields){
     console.log(rows);
    if(err)
      {  
      res.json(err);
      }
      else{
        console.log(rows);
        posts = rows;
        totalData['currentUser'] = currentUser;
        totalData['posts'] = posts;
        console.log("totalData" + totalData);
        res.json(totalData);
      }
      });
  }
  });

   //var currentUserData = loginUser.loginUser(reqBody, res);
  //console.log('currentUserData' + currentUserData);
});

router.post('/registerUser', function(req, res, next) { 
  var reqBody = req.body;
  //res.writeHead(200, {"Content-Type": "application/json"});
  registerUser.registerUser(reqBody);
  res.write('User Registered successfully');
  res.end();
  //res.render('login');
});

router.post('/uploadFile', function(req, res, next){
  console.log('usersession'+req.session);
  var userSession = req.session;
  console.log('usersession'+userSession);
  if(userSession.userid){
    console.log('inside session');
    upload(req,res,function(err){

            if(err){
                 res.json({error_code:1,err_desc:err});
                 console.log('insie err');
                 return;
            }
            res.write(req.file.path);
            res.end();
            console.log('reqfile'+req.file);
            console.log('path'+req.file.path);
             //res.json({error_code:0,err_desc:null});
    })
  }
    else{
      console.log('outside sessnion');
      //res.redirect('/');

    }
  
  
});

router.post('/createPost', function(req, res, next){
var userSession = req.session;
console.log(userSession);
if(userSession.userid){
    console.log('reqbpdy'+req.body.productImage);
  
  Posts.createPostForCurrentUser(req.body, function(err,count){
    if(err)
            {
              console.log('err'+err);
                res.json(err);
            }
            else{
              console.log('inside success');
                    res.json(req.body);//or return count for 1 & 0
            }
  });
  //createPost.createPost(req, res);
  console.log('inside router index.js');
}
  else{
    res.redirect('/');
  }
  
  
});

module.exports = router;