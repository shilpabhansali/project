
(function () {
	'use strict';
	angular
	.module('myApp').controller('createPostController', createPostController);

	createPostController.$inject = ['$rootScope', '$log', '$window', 'PostService', '$scope'];
	function createPostController($rootScope, $log, $window, PostService, $scope) {
		$scope.product = {
			productName: "",
			productRate:"",
			productTitle: "",
			productPros: "",
			productCons: "",
			productReview: "",
			productRecommend:"",
			productImage: "",
			productUser: ""
		};
		
		$rootScope.navBar = true;
		$scope.product.productUser = $rootScope.currentUser; // adding current user details
		$scope.post = function () {
			console.log("POST called");
			PostService.Post($scope.product).then(function(response) {
				console.log(response);
				location.href = "/#post";
				
		}, function(error) {
					
			console.log(error);
			alert("UNABLE TO ADD POST: " + error.message);
		});
		

	};
	}
})();