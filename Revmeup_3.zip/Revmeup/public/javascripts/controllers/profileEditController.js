/* Edit Post */



(function () {
	'use strict';

	angular
	.module('myApp')
	.controller('ProfileEditController', ProfileEditController);

	ProfileEditController.$inject = ['$rootScope', '$log', '$window','$scope'];
	function ProfileEditController($rootScope, $log, $window, $scope) {

		$rootScope.navBar = true;//for the navigation bar
		$scope.tab = 1;

		$scope.setTab = function (tabId) {
			$scope.tab = tabId;
	    };

	    $scope.isSet = function (tabId) {
	        return $scope.tab === tabId;
	    };
	};

})();