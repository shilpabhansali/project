/**
 * Post Service
 */

(function () {
	'use strict';

	angular
	.module('myApp')
	.factory('PostService', PostService);

	PostService.$inject = ['$rootScope', '$http', '$q', '$log'];
	function PostService($rootScope, $http, $q, $log) {
		
		var service = {};

		service.Post = post;
		
		return service;

		function post(product) {
			
			var formData = new FormData();
            formData.append('ProductImage', product.productImage);
            
			var deferred = $q.defer();


			$http({
				method: 'POST',
                url: "/uploadFile",
				dataType: 'json',
				transformRequest: angular.identity,
                data: formData,
                headers: {
                    'Content-Type': undefined
                } 
			}).then(function successCallback(response) {
				//GEtting the path of the file uploaded
				deferred.resolve(response.data);
				alert("product image path="+JSON.stringify(response.data));

				var str = JSON.stringify(response.data);
				  var res = str.split("\\").join('/');
				  res = res.replace('"','');
				  res = res.replace('"','');
				  res = res.replace("public//","");
				  alert(res);

				product.productImage = res;
					$http({
					method: 'POST',
	                url: "/createPost",
	                data: product
				}).then(function successCallback(response) {
					deferred.resolve(response.data);
					console.log("service called!!");

				}, function errorCallback(response) {

					deferred.reject(new Error("ERROR: UNABLE TO GET DOCS: " + response.status));
				});
				console.log("service called!!");
			}, function errorCallback(response) {

				deferred.reject(new Error("ERROR: UNABLE TO GET DOCS: " + response.status));
			});
			
			return deferred.promise;
		}
	}
})();